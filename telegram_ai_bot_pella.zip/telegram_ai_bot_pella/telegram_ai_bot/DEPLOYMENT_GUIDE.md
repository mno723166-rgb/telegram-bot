# 🚀 دليل تشغيل البوت - CV Analysis Bot

## ✅ الحالة الحالية
**البوت يعمل الآن!** يمكنك اختباره على Telegram.

---

## 📱 رابط البوت
ابحث عن البوت باستخدام الـ Token أو اذهب إلى:
`https://t.me/YOUR_BOT_USERNAME`

---

## 💰 كيف يعمل النظام

### تدفق العمل:
```
1. المستخدم يرسل /start
2. يرسل سيرته الذاتية (نص أو PDF)
3. يضغط على رابط PayPal للدفع ($3)
4. بعد الدفع، يضغط "دفعت - أرسل التحليل"
5. AI يحلل السيرة ويرسل:
   - تقرير تحليلي كامل
   - نسخة محسّنة من السيرة
```

---

## 🖥️ تشغيل البوت على سيرفرك الخاص

### الخيار 1: تشغيل مباشر
```bash
cd /home/ubuntu/telegram_ai_bot
python3 bot.py
```

### الخيار 2: تشغيل في الخلفية (مع إعادة تشغيل تلقائي)
```bash
cd /home/ubuntu/telegram_ai_bot
nohup ./run_forever.sh > bot.log 2>&1 &
```

### الخيار 3: تشغيل كـ systemd service (موصى به للإنتاج)
```bash
# نسخ ملف الخدمة
sudo cp cv-bot.service /etc/systemd/system/

# تفعيل وتشغيل الخدمة
sudo systemctl daemon-reload
sudo systemctl enable cv-bot
sudo systemctl start cv-bot

# التحقق من الحالة
sudo systemctl status cv-bot

# عرض السجلات
sudo journalctl -u cv-bot -f
```

---

## 📁 هيكل الملفات
```
telegram_ai_bot/
├── bot.py              # الكود الرئيسي
├── .env                # متغيرات البيئة
├── users.db            # قاعدة البيانات (تُنشأ تلقائيًا)
├── run_forever.sh      # سكريبت التشغيل المستمر
├── cv-bot.service      # ملف systemd
└── DEPLOYMENT_GUIDE.md # هذا الملف
```

---

## ⚙️ متغيرات البيئة (.env)
```
TELEGRAM_BOT_TOKEN=your_token_here
PAYPAL_LINK=https://paypal.me/your_username/3
SERVICE_PRICE=3
```

---

## 🔧 متطلبات السيرفر
- Python 3.11+
- المكتبات:
  ```bash
  pip3 install python-telegram-bot openai python-dotenv PyPDF2
  ```
- متغير البيئة `OPENAI_API_KEY` (مُعد مسبقًا في هذا النظام)

---

## 📊 مراقبة الأداء

### عرض المستخدمين والمدفوعات:
```bash
cd /home/ubuntu/telegram_ai_bot
sqlite3 users.db "SELECT * FROM users;"
```

### عدد المستخدمين:
```bash
sqlite3 users.db "SELECT COUNT(*) FROM users;"
```

### عدد المدفوعات:
```bash
sqlite3 users.db "SELECT COUNT(*) FROM users WHERE paid=1;"
```

---

## 🎯 نصائح للترويج السريع

1. **مجموعات Telegram للباحثين عن عمل** - انشر رابط البوت
2. **مجموعات الخريجين الجدد** - جمهور مستهدف
3. **مجموعات تطوير الذات** - اهتمام عالٍ بالـ CV
4. **Twitter/X** - انشر مع هاشتاقات #وظائف #CV #سيرة_ذاتية

---

## ⏱️ الزمن المتوقع لأول دفعة
**15-30 دقيقة** بعد النشر في المجموعات المناسبة

---

## 🔄 التحديثات المستقبلية (اختياري)
- إضافة لغات أخرى
- تحليل LinkedIn Profile
- باقات مختلفة (Basic/Pro)
- تتبع التحويلات

---

**البوت جاهز للعمل 24/7 بدون تدخل بشري! 🎉**
