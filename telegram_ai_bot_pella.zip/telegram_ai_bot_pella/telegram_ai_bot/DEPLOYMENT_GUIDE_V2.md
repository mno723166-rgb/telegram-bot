# 🚀 دليل تشغيل البوت v2 - نظام دفع آمن

## ✅ الحالة الحالية
**البوت يعمل الآن بنظام دفع آمن!**

---

## 🔒 ما الجديد في v2؟

### إصلاح الثغرة:
- ❌ **قبل**: زر "دفعت" يعطي الخدمة مجانًا
- ✅ **الآن**: التحقق الحقيقي من الدفع عبر NOWPayments API

### طرق الدفع:
1. **العملات الرقمية** (عبر NOWPayments):
   - USDT, BTC, ETH, LTC, وأكثر من 100 عملة
   - تحقق تلقائي من الدفع
   
2. **PayPal**:
   - يحتاج موافقة يدوية من المشرف
   - أمر `/approve <order_id>`

---

## 📱 رابط البوت
**https://t.me/Aistaruae_bot**

---

## 🔄 تسلسل العمل الآمن

```
1. المستخدم يرسل /start
   ↓
2. يرسل سيرته الذاتية
   ↓
3. البوت يُنشئ طلب برقم فريد (order_id)
   ↓
4. البوت يُنشئ فاتورة NOWPayments
   ↓
5. المستخدم يختار طريقة الدفع:
   • العملات الرقمية → صفحة NOWPayments
   • PayPal → رابط PayPal.me
   ↓
6. بعد الدفع، يضغط "تحقق من الدفع"
   ↓
7. البوت يتحقق من NOWPayments API:
   • إذا مدفوع → يُرسل التحليل
   • إذا غير مدفوع → يطلب الانتظار
```

---

## 🛡️ لماذا النظام آمن؟

| الميزة | الشرح |
|--------|-------|
| **رقم طلب فريد** | كل طلب له معرف مختلف |
| **فاتورة NOWPayments** | مرتبطة برقم الطلب |
| **تحقق API** | البوت يسأل NOWPayments عن حالة الدفع |
| **لا غش** | الخدمة تُقدم فقط بعد تأكيد الدفع |

---

## 👨‍💼 للمشرف: الموافقة على دفعات PayPal

عندما يدفع شخص عبر PayPal:
1. تصلك إشعار الدفع في PayPal
2. خذ رقم الطلب من المستخدم
3. أرسل في البوت: `/approve <order_id>`
4. البوت يُرسل التحليل للمستخدم

**لإضافة نفسك كمشرف:**
عدّل السطر في `bot_v2.py`:
```python
ADMIN_IDS = [YOUR_TELEGRAM_USER_ID]
```

---

## 📁 هيكل الملفات
```
telegram_ai_bot/
├── bot_v2.py           # الكود الجديد الآمن
├── bot.py              # الكود القديم (لا تستخدمه)
├── .env                # متغيرات البيئة
├── users.db            # قاعدة البيانات
├── bot.log             # سجل التشغيل
└── DEPLOYMENT_GUIDE_V2.md
```

---

## ⚙️ متغيرات البيئة (.env)
```
TELEGRAM_BOT_TOKEN=your_token
PAYPAL_LINK=https://paypal.me/your_username/3
NOWPAYMENTS_API_KEY=your_api_key
SERVICE_PRICE=3
```

---

## 🖥️ تشغيل البوت

### تشغيل مباشر:
```bash
cd /home/ubuntu/telegram_ai_bot
python3 bot_v2.py
```

### تشغيل في الخلفية:
```bash
cd /home/ubuntu/telegram_ai_bot
nohup python3 bot_v2.py > bot.log 2>&1 &
```

### عرض السجلات:
```bash
tail -f /home/ubuntu/telegram_ai_bot/bot.log
```

---

## 📊 مراقبة الطلبات

### عرض جميع الطلبات:
```bash
sqlite3 users.db "SELECT order_id, user_id, payment_status, created_at FROM orders;"
```

### عدد الطلبات المدفوعة:
```bash
sqlite3 users.db "SELECT COUNT(*) FROM orders WHERE payment_status='paid';"
```

### إجمالي الإيرادات:
```bash
sqlite3 users.db "SELECT SUM(amount) FROM orders WHERE payment_status='paid';"
```

---

## 🎯 الترويج

انشر في مجموعات الباحثين عن عمل:

> 🎯 حلل سيرتك الذاتية في 60 ثانية!
> ✅ تحليل احترافي + نسخة محسّنة
> 💰 $3 فقط (ادفع بالعملات الرقمية أو PayPal)
> 👉 https://t.me/Aistaruae_bot

---

**البوت جاهز للعمل 24/7 بأمان تام! 🔒**
